SELECT time, login, content
FROM journal
ORDER BY time DESC
LIMIT 1
;
